# ex19
Muutin /oppilaat sivun suoraan /opiskelija/index.ejs tiedostossa ja "etusivua" eli localhost:3000 sivua style.css tiedostosta
